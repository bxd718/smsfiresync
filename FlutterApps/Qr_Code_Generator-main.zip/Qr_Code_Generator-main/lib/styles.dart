import 'package:flutter/material.dart';

class AppColors{
  static Color primaryColor = const Color.fromARGB(255, 0, 146, 20);
  static Color white = const Color(0xFFffffff);
}